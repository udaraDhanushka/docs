#!/bin/bash

LIBRARY_FILE="library_books.txt"
REQUEST_FILE="book_requests.txt"
LOG_FILE="library_log.txt"

touch "$LIBRARY_FILE" "$REQUEST_FILE" "$LOG_FILE"

log_action() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

view_books() {
    echo -e "\nAvailable Books:"
    while IFS='|' read -r isbn title author; do
        printf "%-15s %-25s %-20s\n" "ISBN: $isbn" "Title: $title" "Author: $author"
    done < "$LIBRARY_FILE"
}

add_book() {
    read -p "Enter ISBN: " isbn
    read -p "Enter Title: " title
    read -p "Enter Author: " author
    
    if grep -q "^$isbn|" "$LIBRARY_FILE"; then
        echo "Error: Book already exists!"
        log_action "ADD_FAILED: Duplicate ISBN $isbn"
        return 1
    fi
    
    echo "$isbn|$title|$author" >> "$LIBRARY_FILE"
    echo "Book added successfully!"
    log_action "ADDED: $isbn|$title|$author"
}

request_book() {
    read -p "Enter Student ID: " student_id
    read -p "Enter Book ISBN: " isbn
    
    # Validate book exists
    if ! grep -q "^$isbn|" "$LIBRARY_FILE"; then
        echo "Error: Book not found!"
        log_action "REQUEST_FAILED: Invalid ISBN $isbn by $student_id"
        return 1
    fi

    # Check for duplicate request
    if grep -q "|$student_id|$isbn|" "$REQUEST_FILE"; then
        echo "Error: You already requested this book!"
        log_action "REQUEST_FAILED: Duplicate request by $student_id"
        return 1
    fi
    
    # Processing type menu
    echo -e "\nSelect processing type:"
    echo "1. FIFO (First-In-First-Out)"
    echo "2. Priority (Higher priority first)"
    read -p "Choose [1-2]: " processing_type
    
    case "$processing_type" in
        1) priority=0 ;;
        2)
            read -p "Enter priority (1-10): " priority
            if (( priority < 1 || priority > 10 )); then
                echo "Invalid priority! Using default 5."
                priority=5
            fi
            ;;
        *)
            echo "Invalid choice! Using FIFO."
            priority=0
            ;;
    esac
    
    timestamp=$(date +%s)
    echo "$timestamp|$student_id|$isbn|$priority" >> "$REQUEST_FILE"
    echo "Request submitted!"
    log_action "REQUEST: $student_id|$isbn|$priority"
}

view_requests() {
    [ ! -s "$REQUEST_FILE" ] && echo "No pending requests!" && return
    echo -e "\nPending Requests (Oldest First):"
    printf "%-12s %-10s %-15s %-10s\n" "Timestamp" "Student" "ISBN" "Priority"
    while IFS='|' read -r ts student isbn pri; do
        printf "%-12s %-10s %-15s %-10s\n" "$(date -d @$ts '+%H:%M:%S')" "$student" "$isbn" "$pri"
    done < "$REQUEST_FILE"
}

process_fifo() {
    [ ! -s "$REQUEST_FILE" ] && echo "No requests!" && return
    
    IFS='|' read -r ts student_id isbn priority < "$REQUEST_FILE"
    echo "Processing request for Student $student_id (Book $isbn)"
    
    tail -n +2 "$REQUEST_FILE" > temp_queue
    mv temp_queue "$REQUEST_FILE"
    log_action "PROCESSED_FIFO: $student_id|$isbn"
}

process_priority() {
    [ ! -s "$REQUEST_FILE" ] && echo "No requests!" && return
    
    sort -t'|' -k4nr -k1n "$REQUEST_FILE" > temp_queue
    IFS='|' read -r ts student_id isbn priority < temp_queue
    echo "Processing priority request for Student $student_id (Priority: $priority)"
    
    tail -n +2 temp_queue > "$REQUEST_FILE"
    log_action "PROCESSED_PRIORITY: $student_id|$isbn|$priority"
}

exit_system() {
    read -p "Are you sure you want to exit? (Y/N): " confirm
    [[ "$confirm" =~ [Yy] ]] && echo "Goodbye!" && exit 0
}

while true; do
    echo -e "\nLibrary Queue Management System"
    echo "1. View Books"
    echo "2. Add Book"
    echo "3. Request Book"
    echo "4. View Pending Requests"
    echo "5. Process FIFO"
    echo "6. Process Priority"
    echo "7. Exit"
    
    read -p "Choose [1-7]: " choice
    case $choice in
        1) view_books ;;
        2) add_book ;;
        3) request_book ;;
        4) view_requests ;;
        5) process_fifo ;;
        6) process_priority ;;
        7) exit_system ;;
        *) echo "Invalid choice!" ;;
    esac
done
