#!/bin/bash

SUBMISSION_DIR="submissions"
LOG_FILE="submission_log.txt"
HASH_DB="file_hashes.db"

mkdir -p "$SUBMISSION_DIR"
touch "$LOG_FILE" "$HASH_DB"

log_submission() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] | Student: $1 | File: $2 | Size: $3 | Status: $4 | Hash: $5" >> "$LOG_FILE"
}

validate_file() {
    local file="$1"
    local student_id="$2"
    
    # File type check
    if [[ "$file" != *.pdf && "$file" != *.docx ]]; then
        echo "Invalid format! Only PDF/DOCX allowed."
        log_submission "$student_id" "$(basename "$file")" "NA" "REJECTED_FORMAT" "NA"
        return 1
    fi
    
    # Size check (5MB limit)
    local size=$(stat -c%s "$file")
    if (( size > 5242880 )); then
        echo "File too large! Max 5MB."
        log_submission "$student_id" "$(basename "$file")" "$size" "REJECTED_SIZE" "NA"
        return 2
    fi
    
    return 0
}

check_duplicates() {
    local file="$1"
    local student_id="$2"
    local file_hash=$(md5sum "$file" | cut -d' ' -f1)
    
    # Filename duplicate check
    if [[ -f "$SUBMISSION_DIR/$(basename "$file")" ]]; then
        echo "Filename already exists!"
        log_submission "$student_id" "$(basename "$file")" "NA" "REJECTED_NAME_DUP" "$file_hash"
        return 1
    fi
    
    # Content duplicate check
    if grep -q "$file_hash" "$HASH_DB"; then
        echo "Content duplicate detected!"
        log_submission "$student_id" "$(basename "$file")" "NA" "REJECTED_CONTENT_DUP" "$file_hash"
        return 2
    fi
    
    echo "$file_hash" >> "$HASH_DB"
    return 0
}

submit_assignment() {
    read -p "Student ID: " student_id
    read -p "File path: " file_path
    
    [ ! -f "$file_path" ] && echo "File not found!" && return
    
    if validate_file "$file_path" "$student_id" && check_duplicates "$file_path" "$student_id"; then
        filename=$(basename "$file_path")
        cp "$file_path" "$SUBMISSION_DIR/$filename"
        file_size=$(stat -c%s "$file_path")
        file_hash=$(md5sum "$file_path" | cut -d' ' -f1)
        log_submission "$student_id" "$filename" "$file_size" "ACCEPTED" "$file_hash"
        echo "Submission successful!"
    fi
}

check_submission() {
    read -p "Filename to check: " filename
    found=$(find "$SUBMISSION_DIR" -name "$filename" -print -quit 2>/dev/null)
    [ -n "$found" ] && echo "Exists: $found" || echo "Not found"
}

view_history() {
    read -p "Student ID: " student_id
    echo -e "\nSubmission History for $student_id:"
    grep "| Student: $student_id |" "$LOG_FILE" | while read -r line; do
        IFS='|' read -r _ _ file size status hash <<< "$line"
        printf "%-20s %-10s %-15s %-40s\n" "$file" "$size" "$status" "$hash"
    done
}

generate_report() {
    echo -e "\nDuplicate Content Report:"
    sort "$HASH_DB" | uniq -d | while read -r hash; do
        echo "Hash: $hash"
        grep "$hash" "$LOG_FILE" | cut -d'|' -f3,5
    done
}

exit_system() {
    read -p "Are you sure you want to exit? (Y/N): " confirm
    [[ "$confirm" =~ [Yy] ]] && echo "Goodbye!" && exit 0
}

while true; do
    echo -e "\nExamination Submission System"
    echo "1. Submit Assignment"
    echo "2. Check Submission"
    echo "3. View History"
    echo "4. Generate Duplicate Report"
    echo "5. Exit"
    
    read -p "Choose [1-5]: " choice
    case $choice in
        1) submit_assignment ;;
        2) check_submission ;;
        3) view_history ;;
        4) generate_report ;;
        5) exit_system ;;
        *) echo "Invalid choice!" ;;
    esac
done
